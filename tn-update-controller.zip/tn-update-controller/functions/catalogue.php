<?php
if (!defined('ABSPATH')) { exit; }
function tnuc_bundled_registry(): array {
    static $registry;
    if ($registry === null) { $registry = json_decode((string) file_get_contents(TNUC_DIR . 'data/registry.json'), true) ?: []; }
    return $registry;
}
/** The approved publisher may add branded identities; executable legacy trust stays bundled. */
function tnuc_registry(): array {
    $registry = tnuc_bundled_registry();
    foreach (tnuc_catalogue()['plugins'] ?? [] as $id => $entry) {
        $legacy = $registry[$id]['legacy'] ?? [];
        $registry[$id] = array_merge($registry[$id] ?? [], $entry);
        $registry[$id]['legacy'] = $legacy;
    }
    return $registry;
}
function tnuc_catalogue(): array { return (array) tnuc_get('catalogue'); }
/** Readiness is catalogue metadata, separate from activation and GitHub prerelease channels. */
function tnuc_is_beta(array $entry): bool {
    if (is_bool($entry['beta'] ?? null)) { return $entry['beta']; }
    return tnuc_registry()[$entry['id'] ?? '']['beta'] ?? true;
}
function tnuc_beta_badge(array $entry): string {
    return tnuc_is_beta($entry) ? '<span class="tnuc-beta">Beta</span>' : '';
}
function tnuc_catalogue_groups(array $registry, array $releases, array $plugins): array {
    $groups = ['active' => [], 'installed' => [], 'available' => [], 'beta' => []];
    foreach ($registry as $id => $identity) {
        if (!tnuc_domain_allowed($identity)) { continue; }
        $entry = $releases[$id] ?? $identity;
        $active = isset($plugins[$identity['file']]) && (is_multisite() ? is_plugin_active_for_network($identity['file']) : is_plugin_active($identity['file']));
        $group = $active ? 'active' : (isset($plugins[$identity['file']]) ? 'installed' : (tnuc_is_beta($entry) ? 'beta' : 'available'));
        $groups[$group][$id] = $identity;
    }
    return $groups;
}
function tnuc_plugins(): array {
    require_once ABSPATH . 'wp-admin/includes/plugin.php';
    return get_plugins();
}
function tnuc_match(array $entry, array $plugins): bool {
    if (!isset($plugins[$entry['file']])) { return false; }
    $plugin = $plugins[$entry['file']];
    $uri = rtrim((string) ($plugin['UpdateURI'] ?? ''), '/');
    if ($uri !== '') { return $uri === 'https://github.com/' . $entry['owner'] . '/' . $entry['repo']; }
    $author = strtolower(trim(wp_strip_all_tags((string) ($plugin['Author'] ?? ''))));
    return in_array($author, array_map('strtolower', [$entry['author'], $entry['author_header'] ?? $entry['author']]), true);
}
function tnuc_package(array $entry): string {
    return 'https://github.com/' . $entry['owner'] . '/' . $entry['repo'] . '/releases/download/' . rawurlencode($entry['tag']) . '/' . rawurlencode($entry['asset']);
}
function tnuc_release_url(array $entry): string { return 'https://github.com/' . $entry['owner'] . '/' . $entry['repo'] . '/releases/tag/' . rawurlencode($entry['tag']); }
function tnuc_decode_catalogue_response(string $body) {
    $decoded = json_decode($body, true);
    if (!is_array($decoded)) { return null; }
    if (($decoded['schema'] ?? 0) === 1) { return $decoded; }
    if (($decoded['encoding'] ?? '') !== 'base64' || !is_string($decoded['content'] ?? null)) { return null; }
    $content = base64_decode(preg_replace('/\s+/', '', $decoded['content']), true);
    if (!is_string($content)) { return null; }
    $catalogue = json_decode($content, true);
    return is_array($catalogue) ? $catalogue : null;
}
/** @return array|WP_Error */
function tnuc_validate_catalogue($candidate) {
    if (!is_array($candidate) || ($candidate['schema'] ?? 0) !== 1 || !is_array($candidate['plugins'] ?? null) || count($candidate['plugins']) > 200 || !is_string($candidate['published_at'] ?? null) || strtotime($candidate['published_at']) === false) {
        return new WP_Error('catalogue_schema', 'The catalogue format is not supported.');
    }
    $registry = tnuc_registry(); $result = []; $seen = []; $files = [];
    foreach ($candidate['plugins'] as $entry) {
        if (!is_array($entry) || !is_string($entry['id'] ?? null) || isset($seen[$entry['id']])) { return new WP_Error('catalogue_entry', 'The catalogue contains duplicate or invalid entries.'); }
        $id = $entry['id']; $seen[$id] = true;
        if (($entry['owner'] ?? '') !== 'cchatterton' || ($entry['author'] ?? '') !== 'Techn') { return new WP_Error('catalogue_brand', 'A catalogue identity belongs to another publisher or brand.'); }
        foreach (['owner', 'repo', 'file', 'slug', 'asset', 'author'] as $key) {
            if (!is_string($entry[$key] ?? null) || (isset($registry[$id]) && $entry[$key] !== $registry[$id][$key])) { return new WP_Error('catalogue_identity', 'Invalid or changed plugin identity.'); }
        }
        if (!isset($registry[$id])) {
            foreach (['id', 'repo', 'slug'] as $key) {
                if (!is_string($entry[$key] ?? null) || !preg_match('/^[a-zA-Z0-9][a-zA-Z0-9_-]*$/D', $entry[$key])) { return new WP_Error('catalogue_identity', 'Invalid plugin identity.'); }
            }
            if (!is_string($entry['file'] ?? null) || !preg_match('/^' . preg_quote($entry['slug'], '/') . '\/[a-zA-Z0-9_-]+\.php$/D', $entry['file']) || ($entry['asset'] ?? '') !== $entry['slug'] . '.zip' || isset($files[$entry['file']])) { return new WP_Error('catalogue_identity', 'Unsafe or duplicate plugin package identity.'); }
        }
        if (isset($files[$entry['file']])) { return new WP_Error('catalogue_identity', 'Duplicate plugin file.'); }
        foreach ($registry as $known_id => $known) {
            if ($known_id !== $id && ($known['file'] === $entry['file'] || $known['slug'] === $entry['slug'] || $known['repo'] === $entry['repo'])) { return new WP_Error('catalogue_identity', 'A new entry conflicts with an existing plugin identity.'); }
        }
        $files[$entry['file']] = true;
        foreach (['version', 'requires', 'requires_php'] as $key) {
            if (!is_string($entry[$key] ?? null) || !preg_match('/^\d+\.\d+(?:\.\d+){0,2}$/D', $entry[$key])) { return new WP_Error('catalogue_version', 'A catalogue version is invalid.'); }
        }
        if (!in_array($entry['tag'] ?? '', [$entry['version'], 'v' . $entry['version'], 'V' . $entry['version']], true) || !preg_match('/^[a-f0-9]{64}$/D', (string) ($entry['sha256'] ?? '')) || !is_array($entry['dependencies'] ?? null) || !is_int($entry['controller_api'] ?? null)) {
            return new WP_Error('catalogue_package', 'A catalogue package is invalid.');
        }
        foreach ($entry['dependencies'] as $dependency) {
            if (!is_string($dependency) || !preg_match('/^[a-z0-9-]+$/D', $dependency)) { return new WP_Error('catalogue_dependencies', 'A dependency is invalid.'); }
        }
        if (array_key_exists('beta', $entry) && !is_bool($entry['beta'])) { return new WP_Error('catalogue_beta', 'A catalogue beta status is invalid.'); }
        $entry['beta'] = $entry['beta'] ?? ($registry[$id]['beta'] ?? true);
        $entry['allowed_domains'] = $entry['allowed_domains'] ?? [];
        $entry['include_subdomains'] = $entry['include_subdomains'] ?? false;
        if (!tnuc_valid_domain_policy($entry)) { return new WP_Error('catalogue_domains', 'Invalid plugin domain metadata.'); }
        $entry['name'] = sanitize_text_field((string) ($registry[$id]['name'] ?? $entry['name'] ?? $id));
        $entry['description'] = sanitize_text_field((string) ($entry['description'] ?? $registry[$id]['description'] ?? ''));
        $entry['body'] = sanitize_textarea_field((string) ($entry['body'] ?? ''));
        unset($entry['legacy']); // Legacy code trust is bundled, never accepted remotely.
        $registry[$id] = $entry;
        $result[$id] = $entry;
    }
    if (!$result) { return new WP_Error('catalogue_empty', 'No recognised releases were found.'); }
    return ['published_at' => $candidate['published_at'], 'plugins' => $result];
}
/** @return array|WP_Error */
function tnuc_refresh(bool $manual = true, bool $force = false) {
    $state = (array) tnuc_get('check'); $now = time();
    if (($state['retry_at'] ?? 0) > $now) { return new WP_Error('backoff', 'A previous check failed. Retry after ' . gmdate('Y-m-d H:i', $state['retry_at']) . ' UTC.'); }
    if (!$force && ($state['last_success'] ?? 0) > $now - 60) { return ['message' => 'The catalogue was checked less than a minute ago. Showing those results.']; }
    if (!$manual && ($state['next_check'] ?? 0) > $now) { return ['message' => 'The next scheduled check is not due.']; }
    $lock = tnuc_lock('discovery', 60);
    if (!$lock) { return new WP_Error('check_running', 'A catalogue check is already running.'); }
    try {
        // Recheck after atomic acquisition: another worker may have just completed.
        $state = (array) tnuc_get('check');
        if (($state['retry_at'] ?? 0) > time()) { return new WP_Error('backoff', 'The remote service is in backoff. Please retry later.'); }
        if (!$force && ($state['last_success'] ?? 0) > time() - 60) { return ['message' => 'Using the recently completed catalogue check.']; }
        $state['last_attempt'] = $now; $state['job_id'] = wp_generate_uuid4(); $state['status'] = 'running'; tnuc_put('check', $state);
        $catalogue_url = $force ? add_query_arg('tnuc_cache_bust', (string) $now, TNUC_CATALOGUE_URL) : TNUC_CATALOGUE_URL;
        $response = wp_safe_remote_get($catalogue_url, ['timeout' => 8, 'redirection' => 0, 'limit_response_size' => 1048576, 'headers' => ['Accept' => 'application/json', 'User-Agent' => 'TN-Update-Controller/' . TNUC_VERSION]]);
        $code = is_wp_error($response) ? 0 : (int) wp_remote_retrieve_response_code($response);
        $candidate = $code === 200 ? tnuc_decode_catalogue_response((string) wp_remote_retrieve_body($response)) : null;
        $validated = $candidate ? tnuc_validate_catalogue($candidate) : new WP_Error('catalogue_http', 'The catalogue could not be refreshed. Previous results are preserved.');
        if (is_wp_error($validated)) {
            $failures = min(8, (int) ($state['failures'] ?? 0) + 1);
            $retry = $now + min(DAY_IN_SECONDS, 600 * (2 ** ($failures - 1))) + wp_rand(0, 60);
            if (!is_wp_error($response)) {
                $after = wp_remote_retrieve_header($response, 'retry-after');
                $reset = wp_remote_retrieve_header($response, 'x-ratelimit-reset');
                $retry = max($retry, is_numeric($after) ? $now + (int) $after : (int) strtotime((string) $after), is_numeric($reset) ? (int) $reset : 0);
            }
            $state = array_merge($state, ['status' => 'failed', 'failures' => $failures, 'http_code' => $code, 'error' => $validated->get_error_message(), 'retry_at' => $retry, 'next_check' => $retry]);
            tnuc_put('check', $state);
            return $validated;
        }
        tnuc_put('catalogue', $validated);
        tnuc_put('check', ['status' => 'success', 'job_id' => $state['job_id'], 'last_attempt' => $now, 'last_success' => $now, 'failures' => 0, 'retry_at' => 0, 'next_check' => $now + tnuc_settings()['hours'] * HOUR_IN_SECONDS + wp_rand(0, 300)]);
        $transient = get_site_transient('update_plugins');
        set_site_transient('update_plugins', tnuc_project_updates($transient));
        return ['message' => 'Catalogue checked. Native WordPress update notices now reflect the available releases.'];
    } finally { tnuc_unlock('discovery', $lock); }
}
function tnuc_compatibility(array $entry): string {
    global $wp_version;
    if (!tnuc_domain_allowed($entry)) { return 'This plugin is unavailable for this domain.'; }
    if (version_compare(PHP_VERSION, $entry['requires_php'], '<')) { return 'Requires PHP ' . $entry['requires_php']; }
    if (version_compare($wp_version, $entry['requires'], '<')) { return 'Requires WordPress ' . $entry['requires']; }
    if ($entry['controller_api'] > TNUC_API_VERSION && $entry['id'] !== 'tn-update-controller') { return 'Update Techn Update Controller first.'; }
    $plugins = tnuc_plugins();
    foreach ($entry['dependencies'] as $slug) {
        $found = false;
        foreach ($plugins as $file => $plugin) {
            if (dirname($file) === $slug && (is_plugin_active($file) || is_plugin_active_for_network($file))) { $found = true; break; }
        }
        if (!$found) { return 'Requires active plugin: ' . $slug; }
    }
    return '';
}
